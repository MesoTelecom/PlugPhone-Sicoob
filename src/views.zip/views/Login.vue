<template>
<div id= "main-fundo">
  <v-app>
    <v-content>
      <v-container class = "fill-height" fluid>
              <v-card-text class="mt-12" id="centralizado">
                    <!--text--accent-NUMBER altera a cor da letra do texto-->
                    <h1 class="text-center display-1">Seja bem-vindo ao PlugPhone OmniChannel</h1>
                     <!--div que trata botões de Facebook, Google e Linkedin-->
                     <br>
                    <div class="text-center" mt-4>
                          <img alt="Vue logo" src="../assets/PlugPhoneCentro.png"  width="200" height="135,5"/>
                    </div>
                    <br>
                    <v-form style="width: 53%;     margin-left: 23%;">
                      <v-text-field
                      label="Digite seu usuário"
                      name="Email"
                      prepend-icon="email"
                      type="text"
                      color="#ffffff"
                      />

                       <v-text-field
                       id = "password"
                      label="Digite sua senha"
                      name="Password"
                      prepend-icon="lock"
                      type="password"
                      color="#ffffff"
                      />

                    </v-form>
                  </v-card-text>
                     <div class = "text-center" style="width: 100%">
                 <router-link to="/DashboardPrincipal"> <v-btn rounded  color="#61a5e8" class="centralizado" style="color: white;">Login</v-btn></router-link> 
               
                 

                  </div>
      </v-container>
    </v-content>
  </v-app>


</div>
</template>


<style  scoped>

#centralizado{
  margin-left: 3%;
}

h1{

  color: #595E71;
}
 
#fill-height{

  background-color: #243e57;
}

.v-text-field{

  width: 50%;
  margin-left: 24%;
}

.v-btn{

margin-left: 0%;

}
.text-center{

color: #595E71;
position: center;
}

.text-center1{

color: #595E71;
position: center;
background-color: transparent;
}


.cardanna{

 /* background-image: url(../assets/modelo.jpg);*/
 background-repeat: no-repeat;
  background-size:0%;
  


}
.col-md-4{
  color: transparent;
}
.v-btn__content{

  position: center;
}


.show-enter-active,
.show-leave-enter {
    transform: translateX(0);
    transition: all .3s linear;
}
.show-enter,
.show-leave-to {
    transform: translateX(100%);
}

.fill-height{




 background-repeat: no-repeat;
  background-size:100%;

 /* box-shadow: inset 0 0 0 1000px rgba(4, 81, 132, 0.85);*/
background-image: url(../assets/pm2.jpg);
padding: 15px;
background-repeat: no-repeat;
background-size: cover;
background-position: center;


}

 .text-center:hover, .col-md-4:hover{

background-color: transparent;


}
</style>

<script>


export default{

data: () => ({

step: 1



}),


props: {

source: String 

}

}
  

 

</script>
