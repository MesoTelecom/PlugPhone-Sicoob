<template>
  <v-app
    id="inspire"
    class="papel"
    
  >
 
  <navbar />
  
    <SideBar />

    <v-divider color="white" class="mt-1" dark></v-divider>
    <v-container>
      <v-row>
        <v-col cols="12" sm="12">
          <v-toolbar flat color="rgba(0,0,0,0)" class="mt-n5">
            <v-spacer></v-spacer>
          </v-toolbar>

          <v-row class="px-5 mt-n6 ml-5">
            <v-col cols="12" sm="3" v-for="list in lists" :key="list">
              <v-card
                align="center"
                
                class="rounded-circle border pt-10"
                width="200"
                height="200"
                flat
              >
                <v-icon size="60">
                  {{ list.icon }}
                </v-icon>
                

                <v-card-text class="grey--text text-lg-h6">
                  {{ list.title }}
                </v-card-text>

                <v-btn
                  absolute
                  color="#243e57"
                  class="white--text"
                  fab
                  left
                  top
                >
                  <h2>{{ list.count }}</h2>
                </v-btn>
              </v-card>
            </v-col>
          </v-row>
          <div style="display: flex; margin-left: -200px; margin-top: -58px">
            <v-col cols="12" sm="7">
             <History />
            </v-col>
            <br>
            <br>
            <v-col cols="12" sm="5">
              <Appointment />
            </v-col>
        </div>
        </v-col>
        
      </v-row>
     
    </v-container>
 
  </v-app>
  
</template>

<script>
import SideBar from "../components/SideBar";
//import Table from "../components/Table";
import History from "../components/History";
import Appointment from "../components/Appointment";
import Navbar from "../components/Navbar.vue"

export default {
  name: "Home",
  data: () => ({
   
    lists: [
      {
        icon: "fa fa-user-plus",
        title: "Operadores Logados",
        count: 21,
      },
      {
        icon: "fa fa-user-times",
        color: "red",
        title: "Operadores Deslogados",
        count: 41,
       
      },
      {
        icon: "fa fa-pause-circle",
        title: "Operadores em pausa",
        count: 35,
      },
      {
        icon: "fa fa-phone-square",
        title: "Em ligação",
        count: 15,
      },
    ],
  }),

  components: {
    SideBar,
    History,
    Appointment,
    //Table
    Navbar,
  },
};
</script>
<style scoped>
.fa-user-plus{
  color: green;
}
.fa-user-times{
  color: red;
}
.fa-pause-circle{
  color: orange;
}
.fa-phone-square{
  color:steelblue;
}

.border {
  border: 2px solid #243e57 !important;
}
.v-btn--fab.v-size--default.v-btn--absolute.v-btn--top {
  top: 65px !important;
}
.v-btn--absolute.v-btn--left,
.v-btn--fixed.v-btn--left {
  left: -26px !important;
}
</style>