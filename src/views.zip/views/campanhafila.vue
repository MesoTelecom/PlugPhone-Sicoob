<template>
  <v-app
    id="inspire"
    class="papel"
    
  >
    
    <br>
    <Navbar />
      <div class="text-center">
    <v-menu offset-y>
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          color="primary"
          dark
          v-bind="attrs"
          v-on="on"
        >
          Selecione a fila
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="(item, index) in items"
          :key="index"
        >
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
    <v-container>
      <v-row>
        <v-col cols="12" sm="12">
          <v-toolbar flat color="rgba(0,0,0,0)" class="mt-n5">
            <v-spacer></v-spacer>
          </v-toolbar>

          <v-row class="px-5 mt-n6 ml-5">
            <v-col cols="12" sm="3" v-for="list in lists" :key="list">
              <v-card
                align="center"
                color="#F9FAFC"
                class="rounded-circle border pt-10"
                width="200"
                height="200"
                flat
              >
                <v-icon size="60">
                  {{ list.icon }}
                </v-icon>

                <v-card-text class="grey--text text-lg-h6">
                  {{ list.title }}
                </v-card-text>

                <v-btn
                  absolute
                  color="#243e57"
                  class="white--text"
                  fab
                  left
                  top
                >
                  <h2>{{ list.count }}</h2>
                </v-btn>
              </v-card>
            </v-col>
          </v-row>
   
           
            <br>
            <br>
            
        
        </v-col>
        
      </v-row>
     
    </v-container>
<router-link to="./menurealtime" class="linkp">
      <v-btn color="primary" dark v-bind="attrs" v-on="on" class="botaoSair" >voltar</v-btn>
</router-link>
<div>
  <Footer />
</div>
 
  </v-app>
  
</template>


<script>

import Navbar from "../components/Navbar";
import Footer from "../components/footer.vue";


export default {
  name: "Home",
  data: () => ({
  

    lists: [
      {
        icon: "mdi mdi-phone",
        title: "Total de chamadas",
        count: 21,
      },
      {
        icon: "mdi mdi-phone-log",
        title: "Chamadas em fila",
        count: 41,
       
      },
      {
        icon: "mdi mdi-phone-in-talk",
        title: "Chamadas conectadas",
        count: 35,
      },
      {
        icon: "mdi mdi-phone-minus",
        title: "Chamadas abandonadas",
        count: 15,
      },
          {
        icon: "mdi mdi-checkbox-marked-circle",
        title: "Chamadas finalizadas",
        count: 15,
      },
      {
        icon: "mdi mdi-phone-missed",
        title: "Chamadas perdidas",
        count: 15,
      },
      {
        icon: "mdi mdi-alarm",
        title: "Duração média",
        count: 15,
      },
        {
        icon: "mdi mdi-alarm",
        title: "Duração máxima",
        count: 15,
      }

    ],
       items: [
        { title: 'Fila PMMG 190' },
        { title: 'Fila Samu' },
        { title: 'Fila Bombeiros' },
        { title: 'Fila Civil' },
      ],
  }),
  components: {
        Navbar,
        Footer,
      }, 


};
</script>
<style scoped>
.border {
  border: 2px solid #243e57 !important;
}

.v-btn--fab.v-size--default.v-btn--absolute.v-btn--top {
  top: 65px !important;
}
.v-btn--absolute.v-btn--left,
.v-btn--fixed.v-btn--left {
  left: -26px !important;
}
.mdi-phone-in-talk{
color:green;
}
.mdi-alarm{
  color:blue;
}
.linkp{
	text-decoration: none;
}
.botaoSair {
  margin-left: 47%;
  background-color: #ed2020 !important;
  text-decoration: none !important;
}

.mdi-checkbox-marked-circle{
  color: green;
}
.mdi-phone-missed{
  color:red;
}
.mdi-phone-log{
color: orange;
}
.mdi-phone-minus{
  color: orange;
}
.mdi-phone{
  color: blue;
}

</style>